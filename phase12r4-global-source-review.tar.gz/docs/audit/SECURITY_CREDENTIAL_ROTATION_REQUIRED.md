# SECURITY: Credential Rotation Required

## Incident Summary

The Phase 12-R3 source tarball (`phase12r3-global-source-review.tar.gz`) included `mw-backend/env` which contained non‑empty production‑adjacent secrets. This tarball has been **destroyed** and must NOT be redistributed. No evidence of secrets entering Git history was found (`git ls-files` and `git log` show no `mw-backend/env` was ever committed).

The `.gitignore` has been updated to explicitly block `**/env` and `env` (bare, directory name) to prevent recurrence.

## Affected Secrets

The following secrets were present in the local `mw-backend/env` file:

| Secret | Length (chars) | Type |
|--------|---------------|------|
| `PG_PASSWORD` | ~10 | PostgreSQL |
| `MYSQL_ROOT_PASSWORD` | ~10 | MySQL root |
| `MYSQL_PASSWORD` | ~10 | MySQL application |
| `REDIS_PASSWORD` | ~10 | Redis |
| `JWT_SECRET` | ~10 | JWT signing |
| `WORDPRESS_ADMIN_PASSWORD` | ~10 | WordPress admin |

## Required Actions (Human Operator)

> **Status**: `CREDENTIAL_ROTATION_REQUIRED` — this phase cannot complete until confirmed.

### 1. PostgreSQL

Connect to production PostgreSQL and change the password:

```sql
ALTER USER modelwiki WITH PASSWORD '<new-random-64-chars>';
```

Update the local `mw-backend/env` file (which is already `.gitignore`d) and all deployment environments.

### 2. MySQL

```sql
ALTER USER 'modelwiki'@'%' IDENTIFIED BY '<new-random-64-chars>';
ALTER USER 'root'@'%' IDENTIFIED BY '<new-random-64-chars>';
```

### 3. Redis

```
CONFIG SET requirepass "<new-random-64-chars>"
```

Update `REDIS_PASSWORD` in environment.

### 4. JWT Secret

Generate a new secret:

```bash
openssl rand -hex 32
```

Set `JWT_SECRET` in the environment. **Old tokens will be invalid immediately.**

Notify all authenticated users to re-login.

### 5. WordPress Admin

Log into WordPress admin panel and change the admin password. Or use WP-CLI:

```bash
wp user update admin --user_pass="<new-random-64-chars>"
```

Update `WORDPRESS_ADMIN_PASSWORD` in the environment.

## Verification

After rotation, run:

```bash
# Verify no env files are tracked
git ls-files | grep -i env
# Should return only env.example or none

# Verify the tarball excludes env
tar -tzf phase12r4-global-source-review.tar.gz | grep -i env
# Should show only env.example
```

## Confirmation

When all above rotations are complete, output:

```
CREDENTIAL_ROTATION_CONFIRMED
```

This document will be retained in the audit trail.
