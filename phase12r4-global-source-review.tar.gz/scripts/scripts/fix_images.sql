DELETE FROM figure_images;

INSERT INTO figure_images (figure_id, url, alt, sort_order, source)
SELECT f.id,
    'https://placehold.co/400x533/0F172A/E8553D?text=' || replace(replace(replace(replace(coalesce(f.name_en, f.name), ' ', '+'), '/', '%2F'), ':', '%3A'), '#', '%23'),
    f.name, 0, 'placeholder'
FROM figures f;
