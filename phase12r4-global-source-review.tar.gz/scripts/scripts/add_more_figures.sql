INSERT INTO manufacturers (slug, name, name_en) VALUES
('kotobukiya', 'Kotobukiya', 'Kotobukiya'),
('good-smile-company', 'Good Smile Company', 'Good Smile Company'),
('max-factory', 'Max Factory', 'Max Factory'),
('taito', 'Taito', 'Taito'),
('banpresto', 'Banpresto', 'Banpresto'),
('kadokawa', 'Kadokawa', 'Kadokawa')
ON CONFLICT (slug) DO NOTHING;

INSERT INTO series (slug, name, name_en, media_type) VALUES
('re-zero', 'Re:Zero', 'Re:Zero - Starting Life in Another World', 'anime'),
('sword-art-online', 'Sword Art Online', 'Sword Art Online', 'anime'),
('kono-subarashii', 'KonoSuba', 'KonoSuba', 'anime'),
('darling-in-the-franxx', 'DARLING in the FRANXX', 'DARLING in the FRANXX', 'anime'),
('vocaloid', 'Vocaloid', 'Vocaloid', 'game'),
('demon-slayer', 'Demon Slayer', 'Demon Slayer: Kimetsu no Yaiba', 'anime'),
('jujutsu-kaisen', 'Jujutsu Kaisen', 'Jujutsu Kaisen', 'anime'),
('dragon-ball', 'Dragon Ball', 'Dragon Ball Super', 'anime'),
('spy-x-family', 'Spy x Family', 'Spy x Family', 'anime')
ON CONFLICT (slug) DO NOTHING;

DO $$
DECLARE
    m_alter bigint; m_koto bigint; m_gsc bigint; m_mf bigint; m_taito bigint; m_bp bigint; m_kad bigint; m_free bigint;
    s_rezero bigint; s_sao bigint; s_kono bigint; s_ditf bigint; s_voca bigint; s_ds bigint; s_jjk bigint; s_db bigint; s_sxf bigint;
    cat_scale bigint; cat_nendo bigint; cat_figma bigint; cat_prize bigint;
BEGIN
    SELECT id INTO m_alter FROM manufacturers WHERE slug='alter';
    SELECT id INTO m_koto FROM manufacturers WHERE slug='kotobukiya';
    SELECT id INTO m_gsc FROM manufacturers WHERE slug='good-smile-company';
    SELECT id INTO m_mf FROM manufacturers WHERE slug='max-factory';
    SELECT id INTO m_taito FROM manufacturers WHERE slug='taito';
    SELECT id INTO m_bp FROM manufacturers WHERE slug='banpresto';
    SELECT id INTO m_kad FROM manufacturers WHERE slug='kadokawa';
    SELECT id INTO m_free FROM manufacturers WHERE slug='freeing';

    SELECT id INTO s_rezero FROM series WHERE slug='re-zero';
    SELECT id INTO s_sao FROM series WHERE slug='sword-art-online';
    SELECT id INTO s_kono FROM series WHERE slug='kono-subarashii';
    SELECT id INTO s_ditf FROM series WHERE slug='darling-in-the-franxx';
    SELECT id INTO s_voca FROM series WHERE slug='vocaloid';
    SELECT id INTO s_ds FROM series WHERE slug='demon-slayer';
    SELECT id INTO s_jjk FROM series WHERE slug='jujutsu-kaisen';
    SELECT id INTO s_db FROM series WHERE slug='dragon-ball';
    SELECT id INTO s_sxf FROM series WHERE slug='spy-x-family';

    SELECT id INTO cat_scale FROM categories WHERE slug='scale-figure';
    SELECT id INTO cat_nendo FROM categories WHERE slug='nendoroid';
    SELECT id INTO cat_figma FROM categories WHERE slug='figma';
    SELECT id INTO cat_prize FROM categories WHERE slug='prize-figure';

    INSERT INTO figures (slug, name, name_jp, name_en, scale, material, price_jpy, release_date, height_mm, series_id, manufacturer_id) VALUES
    ('rem-1-7-scale-figure-wedding-ver', 'Rem 1/7 Scale Figure (Wedding Ver.)', 'レム 1/7スケールフィギュア ウェディングVer.', 'Rem 1/7 Scale Figure (Wedding Ver.)', '1/7', 'PVC/ABS', 22800, '2025-06-15', 260, s_rezero, m_alter),
    ('asuna-1-7-scale-figure-undine-ver', 'Asuna 1/7 Scale Figure (Undine Ver.)', 'アスナ 1/7スケールフィギュア ウンディーネVer.', 'Asuna 1/7 Scale Figure (Undine Ver.)', '1/7', 'PVC/ABS', 25000, '2025-04-20', 270, s_sao, m_koto),
    ('megumin-1-7-scale-figure', 'Megumin 1/7 Scale Figure', 'めぐみん 1/7スケールフィギュア', 'Megumin 1/7 Scale Figure', '1/7', 'PVC/ABS', 19800, '2025-07-10', 240, s_kono, m_kad),
    ('zero-two-1-7-scale-figure', 'Zero Two 1/7 Scale Figure', 'ゼロツー 1/7スケールフィギュア', 'Zero Two 1/7 Scale Figure', '1/7', 'PVC/ABS', 26800, '2025-09-01', 275, s_ditf, m_alter),
    ('miku-hatsune-1-4-scale-figure-snow-miku-2025', 'Miku Hatsune 1/4 Scale Figure (Snow Miku 2025)', '初音ミク 1/4スケールフィギュア スノーミク2025', 'Miku Hatsune 1/4 Scale Figure (Snow Miku 2025)', '1/4', 'PVC/ABS', 38000, '2025-02-14', 400, s_voca, m_free),
    ('nezuko-kamado-nendoroid', 'Nezuko Kamado Nendoroid', '竈門禰豆子 ねんどろいど', 'Nezuko Kamado Nendoroid', NULL, 'PVC/ABS', 5500, '2025-05-20', 100, s_ds, m_gsc),
    ('gojo-satoru-figma', 'Gojo Satoru figma', '五条悟 figma', 'Gojo Satoru figma', NULL, 'PVC/ABS', 9800, '2025-08-15', 155, s_jjk, m_mf),
    ('anya-forger-prize-figure', 'Anya Forger Prize Figure', 'アーニャ・フォージャー プライズフィギュア', 'Anya Forger Prize Figure', NULL, 'PVC', 3500, '2025-03-01', 140, s_sxf, m_taito),
    ('emilia-1-7-scale-figure-ice-season-ver', 'Emilia 1/7 Scale Figure (Ice Season Ver.)', 'エミリア 1/7スケールフィギュア アイスシーズンVer.', 'Emilia 1/7 Scale Figure (Ice Season Ver.)', '1/7', 'PVC/ABS', 23500, '2025-11-20', 265, s_rezero, m_alter),
    ('goku-ultra-instinct-1-6-scale-figure', 'Goku Ultra Instinct 1/6 Scale Figure', '孫悟空 身勝手の極意 1/6スケールフィギュア', 'Goku Ultra Instinct 1/6 Scale Figure', '1/6', 'PVC/ABS/Resin', 45000, '2025-12-01', 350, s_db, m_bp)
    ON CONFLICT (slug) DO NOTHING;

    INSERT INTO figure_category (figure_id, category_id)
    SELECT f.id, cat_scale FROM figures f WHERE f.slug IN ('rem-1-7-scale-figure-wedding-ver','asuna-1-7-scale-figure-undine-ver','megumin-1-7-scale-figure','zero-two-1-7-scale-figure','miku-hatsune-1-4-scale-figure-snow-miku-2025','emilia-1-7-scale-figure-ice-season-ver','goku-ultra-instinct-1-6-scale-figure')
    ON CONFLICT DO NOTHING;

    INSERT INTO figure_category (figure_id, category_id)
    SELECT f.id, cat_nendo FROM figures f WHERE f.slug = 'nezuko-kamado-nendoroid'
    ON CONFLICT DO NOTHING;

    INSERT INTO figure_category (figure_id, category_id)
    SELECT f.id, cat_figma FROM figures f WHERE f.slug = 'gojo-satoru-figma'
    ON CONFLICT DO NOTHING;

    INSERT INTO figure_category (figure_id, category_id)
    SELECT f.id, cat_prize FROM figures f WHERE f.slug = 'anya-forger-prize-figure'
    ON CONFLICT DO NOTHING;
END $$;
