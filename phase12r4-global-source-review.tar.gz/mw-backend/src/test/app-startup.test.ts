import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { buildApp } from "../app.js";

const ADMIN_REVIEW_ROUTES = [
  ["GET", "/api/v1/admin/review/items"],
  ["GET", "/api/v1/admin/review/decisions"],
  ["GET", "/api/v1/admin/review/stats"],
  ["POST", "/api/v1/admin/review/items"],
  ["PUT", "/api/v1/admin/review/items/:id"],
  ["POST", "/api/v1/admin/review/items/:id/recheck"],
  ["POST", "/api/v1/admin/review/items/:id/action"],
  ["POST", "/api/v1/admin/review/items/:id/apply"],
  ["POST", "/api/v1/admin/review/items/bulk/cleanup"],
  ["GET", "/api/v1/admin/review/image-proxy"],
  ["POST", "/api/v1/admin/review/cache-candidate"],
];

describe("App startup — no missing dependencies", () => {
  let app: any;

  beforeAll(async () => {
    app = await buildApp({ skipLifecycle: true });
    // Must listen on ephemeral port so Fastify v5 internal address getters work
    await app.listen({ port: 0, host: "127.0.0.1" });
  });

  afterAll(async () => {
    if (app) await app.close();
  });

  it("buildApp creates a valid app instance", () => {
    expect(app).toBeDefined();
    expect(app.inject).toBeDefined();
  });

  it("app.ready() resolves without error", async () => {
    await expect(app.ready()).resolves.not.toThrow();
  });

  it("registered review routes are not 404 (route existence check)", async () => {
    for (const [method, url] of ADMIN_REVIEW_ROUTES) {
      const res = await app.inject({ method, url });
      expect(res.statusCode).not.toBe(404);
    }
  });

  it("non-existent route returns 404", async () => {
    const res = await app.inject({ method: "GET", url: "/api/v1/nonexistent-route-test" });
    expect(res.statusCode).toBe(404);
  });
});
