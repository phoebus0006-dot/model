import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { buildApp } from "../app.js";

function makeToken(app: any, userId = "1"): string {
  return app.jwt.sign({ userId, role: "admin", iat: Math.floor(Date.now() / 1000) });
}

const mockPrisma = {
  $disconnect: async () => {},
  $transaction: async (fn: any) => fn(mockPrisma),
  figure: {
    findFirst: async () => null, findMany: async () => [],
    findUnique: async () => null, count: async () => 0,
    create: async (a: any) => ({ id: BigInt(1), slug: "test-figure", ...a.data }),
    update: async (a: any) => ({ id: BigInt(1), slug: "test-figure", ...a.data }),
    deleteMany: async () => ({ count: 0 }), updateMany: async () => ({ count: 0 }),
  },
  figureImage: {
    findFirst: async () => null, findMany: async () => [],
    create: async (a: any) => a.data, update: async (a: any) => a.data,
    deleteMany: async () => ({ count: 0 }),
  },
  revision: {
    findFirst: async () => null, aggregate: async () => ({ _max: { versionNumber: 0 } }),
    create: async (a: any) => ({ id: BigInt(1), ...a.data }),
    updateMany: async () => ({ count: 0 }),
  },
  figureCategory: { deleteMany: async () => ({ count: 0 }), create: async (a: any) => a.data },
  figureSculptor: { deleteMany: async () => ({ count: 0 }), create: async (a: any) => a.data },
  figureCharacter: { deleteMany: async () => ({ count: 0 }), create: async (a: any) => a.data },
  figureLocalizedInfo: { deleteMany: async () => ({ count: 0 }), create: async (a: any) => a.data },
  figureRelease: { deleteMany: async () => ({ count: 0 }), create: async (a: any) => a.data },
  user: { findFirst: async () => ({ id: BigInt(1), role: "admin", isActive: true }), findUnique: async () => ({ id: BigInt(1), role: "admin", isActive: true }), count: async () => 1 },
};

function makeRedis(initial?: Record<string, string>): any {
  const store: Record<string, string> = { ...(initial || {}) };
  return {
    get: async (k: string) => store[k] || null,
    set: async (k: string, v: string, ...args: string[]) => {
      if (args.includes("NX") && store[k]) return null;
      store[k] = v;
      return "OK";
    },
    del: async (k: string) => { delete store[k]; return 1; },
    eval: async (script: string, n: number, k: string, t: string) => {
      if (store[k] === t) return 1;
      return 0;
    },
    scan: async () => ["0", []] as [string, string[]],
    zrevrange: async () => [] as string[],
    zcard: async () => 0,
    zadd: async () => 0,
    unlink: async () => 0,
    quit: async () => "OK",
    on: () => {},
    status: "ready",
  };
}

const BASE_ITEM = {
  id: "test-apply-1", type: "figure_import", title: "Test Figure",
  status: "pending", priority: 1,
  createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(),
  payload: {
    figure: { slug: "test-figure", name: "Test Figure", janCode: "1234567890123", categoryIds: [1] },
  },
};

describe("Apply production path", () => {
  let app: any;
  let token: string;

  beforeAll(async () => {
    app = await buildApp({ skipLifecycle: true });
    await app.listen({ port: 0, host: "127.0.0.1" });
    token = makeToken(app);
  });

  afterAll(async () => {
    if (app) await app.close();
  });

  it("1. figure_import succeeds", async () => {
    const redis = makeRedis({ "review:item:test-apply-1": JSON.stringify(BASE_ITEM) });
    const testApp = await buildApp({ prismaOverride: mockPrisma, redisOverride: redis });
    await testApp.listen({ port: 0, host: "127.0.0.1" });
    const t = makeToken(testApp);
    const res = await testApp.inject({
      method: "POST", url: "/api/v1/admin/review/items/test-apply-1/apply",
      headers: { authorization: `Bearer ${t}` },
      body: {},
    });
    expect(res.statusCode).toBe(200);
    await testApp.close();
  });

  it("2. jan_match succeeds", async () => {
    const item = { ...BASE_ITEM, id: "test-apply-2", type: "jan_match", figureSlug: "test-figure" };
    const prisma = { ...mockPrisma, figure: { ...mockPrisma.figure, findFirst: async () => ({ id: BigInt(1), slug: "test-figure", janCode: "old" }) } };
    const redis = makeRedis({ "review:item:test-apply-2": JSON.stringify(item) });
    const testApp = await buildApp({ prismaOverride: prisma, redisOverride: redis });
    await testApp.listen({ port: 0, host: "127.0.0.1" });
    const t = makeToken(testApp);
    const res = await testApp.inject({
      method: "POST", url: "/api/v1/admin/review/items/test-apply-2/apply",
      headers: { authorization: `Bearer ${t}` },
      body: { janCode: "9876543210987" },
    });
    expect(res.statusCode).toBe(200);
    await testApp.close();
  });

  it("3. rewrite succeeds", async () => {
    const item = { ...BASE_ITEM, id: "test-apply-3", type: "rewrite", figureSlug: "test-figure" };
    const redis = makeRedis({ "review:item:test-apply-3": JSON.stringify(item) });
    const testApp = await buildApp({ prismaOverride: mockPrisma, redisOverride: redis });
    await testApp.listen({ port: 0, host: "127.0.0.1" });
    const t = makeToken(testApp);
    const res = await testApp.inject({
      method: "POST", url: "/api/v1/admin/review/items/test-apply-3/apply",
      headers: { authorization: `Bearer ${t}` },
      body: { contentMd: "# Revised content\n\nNew paragraph for testing purposes which exceeds 80 characters in total length for validation." },
    });
    expect(res.statusCode).toBe(200);
    await testApp.close();
  });

  it("4. unknown fields return 422", async () => {
    const redis = makeRedis({ "review:item:test-apply-4": JSON.stringify(BASE_ITEM) });
    const testApp = await buildApp({ prismaOverride: mockPrisma, redisOverride: redis });
    await testApp.listen({ port: 0, host: "127.0.0.1" });
    const t = makeToken(testApp);
    const res = await testApp.inject({
      method: "POST", url: "/api/v1/admin/review/items/test-apply-4/apply",
      headers: { authorization: `Bearer ${t}` },
      body: { unknownField: "shouldReject" },
    });
    expect(res.statusCode).toBe(422);
    await testApp.close();
  });

  it("5. lock conflict returns 409", async () => {
    const lockKey = "review:apply:lock:test-apply-5";
    const redis = makeRedis({ "review:item:test-apply-5": JSON.stringify(BASE_ITEM), [lockKey]: "other-token" });
    const testApp = await buildApp({ prismaOverride: mockPrisma, redisOverride: redis });
    await testApp.listen({ port: 0, host: "127.0.0.1" });
    const t = makeToken(testApp);
    const res = await testApp.inject({
      method: "POST", url: "/api/v1/admin/review/items/test-apply-5/apply",
      headers: { authorization: `Bearer ${t}` },
      body: {},
    });
    expect(res.statusCode).toBe(409);
    await testApp.close();
  });

  it("6. review not found returns 404", async () => {
    const redis = makeRedis({});
    const testApp = await buildApp({ prismaOverride: mockPrisma, redisOverride: redis });
    await testApp.listen({ port: 0, host: "127.0.0.1" });
    const t = makeToken(testApp);
    const res = await testApp.inject({
      method: "POST", url: "/api/v1/admin/review/items/nonexistent/apply",
      headers: { authorization: `Bearer ${t}` },
      body: {},
    });
    expect(res.statusCode).toBe(404);
    await testApp.close();
  });

  it("7. invalid review state returns 409", async () => {
    const resolvedItem = { ...BASE_ITEM, id: "test-apply-7", status: "resolved" };
    const redis = makeRedis({ "review:item:test-apply-7": JSON.stringify(resolvedItem) });
    const testApp = await buildApp({ prismaOverride: mockPrisma, redisOverride: redis });
    await testApp.listen({ port: 0, host: "127.0.0.1" });
    const t = makeToken(testApp);
    const res = await testApp.inject({
      method: "POST", url: "/api/v1/admin/review/items/test-apply-7/apply",
      headers: { authorization: `Bearer ${t}` },
      body: {},
    });
    expect(res.statusCode).toBe(409);
    await testApp.close();
  });

  it("8. unsupported review type returns 422", async () => {
    const badItem = { ...BASE_ITEM, id: "test-apply-8", type: "unsupported_type" };
    const redis = makeRedis({ "review:item:test-apply-8": JSON.stringify(badItem) });
    const testApp = await buildApp({ prismaOverride: mockPrisma, redisOverride: redis });
    await testApp.listen({ port: 0, host: "127.0.0.1" });
    const t = makeToken(testApp);
    const res = await testApp.inject({
      method: "POST", url: "/api/v1/admin/review/items/test-apply-8/apply",
      headers: { authorization: `Bearer ${t}` },
      body: {},
    });
    expect(res.statusCode).toBe(422);
    await testApp.close();
  });

  it("9. missing auth returns 401", async () => {
    const redis = makeRedis({ "review:item:test-apply-9": JSON.stringify(BASE_ITEM) });
    const testApp = await buildApp({ prismaOverride: mockPrisma, redisOverride: redis });
    await testApp.listen({ port: 0, host: "127.0.0.1" });
    const res = await testApp.inject({
      method: "POST", url: "/api/v1/admin/review/items/test-apply-9/apply",
      body: {},
    });
    expect(res.statusCode).toBe(401);
    await testApp.close();
  });

  it("10. figure identity conflict returns 422", async () => {
    const payload = { figure: { slug: "slug-a", name: "Figure A", janCode: "123" } };
    const prisma = {
      ...mockPrisma,
      figure: {
        ...mockPrisma.figure,
        findFirst: async (args: any) => {
          if (args?.where?.slug === "slug-a") return { id: BigInt(1), slug: "slug-a" };
          if (args?.where?.janCode === "123") return { id: BigInt(2), slug: "other-slug" };
          return null;
        },
      },
    };
    const item = { ...BASE_ITEM, id: "test-apply-10", payload };
    const redis = makeRedis({ "review:item:test-apply-10": JSON.stringify(item) });
    const testApp = await buildApp({ prismaOverride: prisma, redisOverride: redis });
    await testApp.listen({ port: 0, host: "127.0.0.1" });
    const t = makeToken(testApp);
    const res = await testApp.inject({
      method: "POST", url: "/api/v1/admin/review/items/test-apply-10/apply",
      headers: { authorization: `Bearer ${t}` },
      body: {},
    });
    expect(res.statusCode).toBe(422);
    await testApp.close();
  });
});
