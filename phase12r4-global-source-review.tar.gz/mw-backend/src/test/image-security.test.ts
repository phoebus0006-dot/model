import { describe, it, expect } from "vitest";
import { validateImageUrl, type DnsResolver } from "../modules/images/image-security.js";

function mockResolver(localIp = "93.184.216.34"): DnsResolver {
  return {
    resolve4: async (host: string) => {
      const blocked = new Set(["localhost", "127.0.0.1", "0.0.0.0", "metadata.google.internal", "169.254.169.254", "100.100.100.200", "metadata.internal"]);
      if (blocked.has(host)) throw new Error("DNS resolution failed");
      const directIps = new Set(["10.0.0.1", "192.168.1.1", "172.16.0.1", "169.254.169.254", "127.0.0.1", "0.0.0.0"]);
      if (directIps.has(host)) return [host];
      if (host === "metadata.google.internal") return ["169.254.169.254"];
      return [localIp];
    },
    resolve6: async () => { throw new Error("No AAAA record"); },
  };
}

describe("image security — URL validation (hermetic)", () => {
  it("allows https URL", async () => {
    const r = await validateImageUrl("https://example.com/img.jpg", mockResolver());
    expect(r.ok).toBe(true);
  });

  it("allows http URL", async () => {
    const r = await validateImageUrl("http://example.com/img.jpg", mockResolver());
    expect(r.ok).toBe(true);
  });

  it("rejects ftp URL", async () => {
    const r = await validateImageUrl("ftp://example.com/img.jpg", mockResolver());
    expect(r.ok).toBe(false);
  });

  it("rejects localhost", async () => {
    const r = await validateImageUrl("http://localhost:8080/img.jpg", mockResolver());
    expect(r.ok).toBe(false);
  });

  it("rejects 127.0.0.1", async () => {
    const r = await validateImageUrl("http://127.0.0.1/img.jpg", mockResolver());
    expect(r.ok).toBe(false);
  });

  it("rejects 0.0.0.0", async () => {
    const r = await validateImageUrl("http://0.0.0.0/img.jpg", mockResolver());
    expect(r.ok).toBe(false);
  });

  it("rejects private IP 10.x.x.x", async () => {
    const r = await validateImageUrl("http://10.0.0.1/img.jpg", mockResolver());
    expect(r.ok).toBe(false);
  });

  it("rejects private IP 192.168.x.x", async () => {
    const r = await validateImageUrl("http://192.168.1.1/img.jpg", mockResolver());
    expect(r.ok).toBe(false);
  });

  it("rejects private IP 172.16.x.x", async () => {
    const r = await validateImageUrl("http://172.16.0.1/img.jpg", mockResolver());
    expect(r.ok).toBe(false);
  });

  it("rejects metadata IP 169.254.169.254", async () => {
    const r = await validateImageUrl("http://169.254.169.254/img.jpg", mockResolver());
    expect(r.ok).toBe(false);
  });

  it("rejects GCP metadata hostname", async () => {
    const r = await validateImageUrl("http://metadata.google.internal/img.jpg", mockResolver());
    expect(r.ok).toBe(false);
  });

  it("rejects malformed URL", async () => {
    const r = await validateImageUrl("not-a-url", mockResolver());
    expect(r.ok).toBe(false);
  });

  it("rejects empty URL", async () => {
    const r = await validateImageUrl("", mockResolver());
    expect(r.ok).toBe(false);
  });

  it("rejects URL without protocol", async () => {
    const r = await validateImageUrl("//evil.com/img.jpg", mockResolver());
    expect(r.ok).toBe(false);
  });
});
