import type { Redis } from "ioredis";
import type { PrismaClient } from "@prisma/client";
import sharp from "sharp";
import fs from "fs";
import path from "path";
import crypto from "crypto";
import { z } from "zod";
import { type LockLease } from "./apply-lock.js";
import { ApplyDependencyError, ApplyValidationError } from "./apply-errors.js";
import { scanKeys } from "../../shared/cache/scan-keys.js";
import {
  processAndStoreImageFiles, computeSha256,
  validateJanCode, validateSha256,
  getReviewImageFilePath, REVIEW_IMAGE_SIZES, safeBigInt,
} from "../images/image-storage.js";
import { validateImageUrl } from "../images/image-security.js";
import { upsertFigureImageRecord } from "../images/image-repository.js";
import {
  figureImportApplySchema, janMatchApplySchema, rewriteApplySchema,
  imageApplySchema, imageReviewApplySchema,
} from "./schemas.js";

const ASSETS_PATH = process.env.ASSETS_PATH || "/app/assets";
const MAX_REDIRECTS = 5;
const DOWNLOAD_TIMEOUT = 15_000;
const MAX_RESPONSE_SIZE = 15 * 1024 * 1024;

export interface ApplyBusinessContext {
  redis: Redis;
  prisma: PrismaClient;
  actorUserId: string;
  requestId?: string;
}

export interface ApplyBusinessInput {
  reviewItemId: string;
  action?: string;
  body: Record<string, unknown>;
}

export interface ApplyBusinessResult {
  success: boolean;
  applied: unknown;
  reviewStatus: string;
  problems: string[];
  figure?: { id: string; slug: string };
  partialSideEffects?: { figureCreated?: boolean; imagesImported?: number };
  failureStage?: string;
}

async function resolveFigure(prisma: PrismaClient, item: any, payload: any) {
  const slug = item.figureSlug || payload.figureSlug || payload.slug || payload.figure?.slug;
  const id = item.figureId || payload.figureId || payload.figure?.id;
  if (id !== undefined && id !== null && /^\d+$/.test(String(id))) {
    const byId = await prisma.figure.findFirst({ where: { id: BigInt(String(id)), isDeleted: false }, select: { id: true, slug: true, name: true, janCode: true, activeRevisionId: true } });
    if (byId) return byId;
  }
  if (slug) return prisma.figure.findFirst({ where: { slug: String(slug), isDeleted: false }, select: { id: true, slug: true, name: true, janCode: true, activeRevisionId: true } });
  return null;
}

async function downloadImage(ctx: ApplyBusinessContext, imageUrl: string, resolvedAddress?: string, redirectDepth = 0): Promise<{ buffer: Buffer; contentType: string }> {
  if (redirectDepth > MAX_REDIRECTS) return Promise.reject(new Error("Too many redirects"));
  const { ok, resolvedAddress: addr } = await validateImageUrl(imageUrl);
  if (!ok) return Promise.reject(new Error("URL validation failed"));

  const targetAddress = resolvedAddress || addr;
  const urlObj = new URL(imageUrl);
  const http = imageUrl.startsWith("https") ? await import("https") : await import("http");
  const client = imageUrl.startsWith("https") ? (http as typeof import("https")) : (http as typeof import("http"));

  return new Promise((resolve, reject) => {
    const options: any = {
      hostname: targetAddress,
      port: urlObj.port || (imageUrl.startsWith("https") ? 443 : 80),
      path: urlObj.pathname + urlObj.search,
      method: "GET",
      timeout: DOWNLOAD_TIMEOUT,
      headers: { "User-Agent": "ModelWiki/1.0", Host: urlObj.hostname },
      rejectUnauthorized: true,
    };
    const req = client.get(options, (res: any) => {
      if ((res.statusCode === 301 || res.statusCode === 302) && res.headers.location) {
        const nextUrl = new URL(res.headers.location, imageUrl).href;
        const nextCheck = validateImageUrl(nextUrl);
        if (!nextCheck) return reject(new Error("Redirect target blocked"));
        return downloadImage(ctx, nextUrl, undefined, redirectDepth + 1).then(resolve).catch(reject);
      }
      if (res.statusCode !== 200) return reject(new Error(`HTTP ${res.statusCode}`));
      const ct = res.headers["content-type"] || "";
      if (ct && !ct.startsWith("image/")) return reject(new Error("Not an image"));
      const chunks: Buffer[] = [];
      let totalSize = 0;
      res.on("data", (chunk: Buffer) => {
        totalSize += chunk.length;
        if (totalSize > MAX_RESPONSE_SIZE) { req.destroy(); reject(new Error("Response too large")); }
        chunks.push(chunk);
      });
      res.on("end", () => resolve({ buffer: Buffer.concat(chunks), contentType: ct }));
    });
    req.on("error", reject);
    req.on("timeout", () => { req.destroy(); reject(new Error("Download timeout")); });
  });
}

async function storeProcessedReviewImage(ctx: ApplyBusinessContext, figureId: bigint, janCode: string, data: any) {
  const size = String(data.size || "");
  const submittedSha256 = String(data.sha256 || "");
  if (!REVIEW_IMAGE_SIZES.has(size)) throw new Error("Invalid processed image size: " + size);
  if (!/^[a-f0-9]{64}$/i.test(submittedSha256)) throw new Error("Invalid processed image sha256");
  if (!data.contentBase64) throw new Error("Missing processed image contentBase64");
  const buffer = Buffer.from(String(data.contentBase64), "base64");
  if (!buffer.length) throw new Error("Processed image content is empty");

  const actualSha256 = computeSha256(buffer);
  if (actualSha256 !== submittedSha256) throw new Error("SHA-256 mismatch: submitted=" + submittedSha256 + " actual=" + actualSha256);

  const metadata = await sharp(buffer).metadata();
  if (!metadata.format || !metadata.width || !metadata.height) throw new Error("Not a valid image");

  const webpBuffer = await sharp(buffer).webp({ quality: 85 }).toBuffer();

  if (!validateJanCode(janCode)) throw new Error("Invalid janCode: " + janCode);
  const filePath = getReviewImageFilePath(janCode, actualSha256, size);

  const resolvedPath = path.resolve(filePath);
  const expectedRoot = path.resolve(ASSETS_PATH, "figures");
  if (!resolvedPath.startsWith(expectedRoot)) throw new Error("Path traversal detected");

  const tmpPath = filePath + ".tmp." + crypto.randomBytes(8).toString("hex");
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  try {
    fs.writeFileSync(tmpPath, webpBuffer);
    fs.renameSync(tmpPath, filePath);
  } catch (e) {
    try { fs.unlinkSync(tmpPath); } catch {}
    throw e;
  }

  const payload = {
    figureId, janCode, sha256: actualSha256, size, format: "webp",
    width: metadata.width, height: metadata.height,
    fileSize: webpBuffer.length, alt: data.alt || null,
    sortOrder: data.sortOrder ?? 0, source: data.source || null, isNsfw: data.isNsfw || false,
  };
  const { image, created } = await upsertFigureImageRecord(ctx.prisma, payload);
  return { image, sha256: actualSha256, updated: !created };
}

async function resolveFigureExact(prisma: PrismaClient, slug: string): Promise<any> {
  return prisma.figure.findFirst({ where: { slug: String(slug), isDeleted: false }, select: { id: true, slug: true, name: true, janCode: true } });
}

async function resolveFigureByJanCode(prisma: PrismaClient, janCode: string): Promise<any> {
  return prisma.figure.findFirst({ where: { janCode: String(janCode), isDeleted: false }, select: { id: true, slug: true, name: true, janCode: true } });
}

async function handleFigureImport(ctx: ApplyBusinessContext, item: any, payload: any, lease: LockLease): Promise<{ applied: any; partialSideEffects?: { figureCreated: boolean }; failureStage?: string }> {
  const figurePayload = payload.figure || {};
  if (!figurePayload.slug || !figurePayload.name) {
    throw new ApplyValidationError("Missing figure slug or name in payload");
  }
  const { categoryIds, sculptorIds, characterIds, images, localized, releases, releaseDate, ...figureData } = figurePayload;

  const allowedFields = ["slug", "name", "janCode", "description", "scale", "material", "priceJpy",
    "heightMm", "weightG", "productLine", "ageRating", "isNsfw",
    "manufacturerId", "seriesId", "originalNameJa", "originalNameZh"];
  const unknownFields = Object.keys(figureData).filter((k) => !allowedFields.includes(k));
  if (unknownFields.length > 0) throw new ApplyValidationError("Unknown figure fields: " + unknownFields.join(", "));

  const slugFigure = figurePayload.slug ? await resolveFigureExact(ctx.prisma, figurePayload.slug) : null;
  let janCodeFigure: any = null;
  if (figurePayload.janCode) {
    janCodeFigure = await resolveFigureByJanCode(ctx.prisma, figurePayload.janCode);
  }
  if (slugFigure && janCodeFigure && slugFigure.id !== janCodeFigure.id) {
    throw new ApplyValidationError("FIGURE_IDENTITY_CONFLICT: slug and janCode point to different figures");
  }
  const existingFigure = slugFigure || janCodeFigure;

  const cleanFigureData: any = {};
  for (const k of allowedFields) {
    if (figurePayload[k] !== undefined) cleanFigureData[k] = figurePayload[k];
  }

  const relationData: any = {
    releaseDate: releaseDate ? new Date(releaseDate) : undefined,
    categories: categoryIds ? { deleteMany: {}, create: categoryIds.map((categoryId: number) => ({ category: { connect: { id: categoryId } } })) } : undefined,
    sculptors: sculptorIds ? { deleteMany: {}, create: sculptorIds.map((s: any) => ({ sculptor: { connect: { id: s.id } }, role: s.role, isPrimary: s.isPrimary ?? false })) } : undefined,
    characters: characterIds ? { deleteMany: {}, create: characterIds.map((c: any) => ({ character: { connect: { id: c.id } }, isFeatured: c.isFeatured ?? false })) } : undefined,
    localized: localized ? { deleteMany: {}, create: localized.map((loc: any) => ({ language: loc.language, title: loc.title, origin: loc.origin, character: loc.character, description: loc.description })) } : undefined,
    releases: releases ? { deleteMany: {}, create: releases.map((rel: any) => ({ edition: rel.edition, releaseDate: rel.releaseDate ? new Date(rel.releaseDate) : undefined, priceJpy: rel.priceJpy ?? undefined, isRerelease: rel.isRerelease ?? false })) } : undefined,
  };
  Object.keys(relationData).forEach((key) => relationData[key] === undefined && delete relationData[key]);

  lease.assertHeld();
  const savedFigure = existingFigure
    ? await ctx.prisma.figure.update({ where: { id: existingFigure.id }, data: { ...cleanFigureData, ...relationData } })
    : await ctx.prisma.figure.create({
        data: {
          ...cleanFigureData,
          releaseDate: releaseDate ? new Date(releaseDate) : undefined,
          categories: { create: categoryIds?.map((categoryId: number) => ({ category: { connect: { id: categoryId } } })) || [] },
          sculptors: { create: sculptorIds?.map((s: any) => ({ sculptor: { connect: { id: s.id } }, role: s.role, isPrimary: s.isPrimary ?? false })) || [] },
          characters: { create: characterIds?.map((c: any) => ({ character: { connect: { id: c.id } }, isFeatured: c.isFeatured ?? false })) || [] },
          localized: { create: localized?.map((loc: any) => ({ language: loc.language, title: loc.title, origin: loc.origin, character: loc.character, description: loc.description })) || [] },
          releases: { create: releases?.map((rel: any) => ({ edition: rel.edition, releaseDate: rel.releaseDate ? new Date(rel.releaseDate) : undefined, priceJpy: rel.priceJpy ?? undefined, isRerelease: rel.isRerelease ?? false })) || [] },
        },
      });

  lease.assertHeld();
  const imageImport = { created: 0, errors: [] as Array<{ source: string; error: string }> };
  const hasImages = payload.importImages !== false && images && images.length > 0;
  const imagesRequired = payload.importImages !== false;

  if (hasImages) {
    const janCode = figurePayload.janCode || savedFigure.janCode || "no-jancode";
    for (let i = 0; i < images.length; i++) {
      const img = images[i];
      try {
        const { ok } = await validateImageUrl(img.source);
        if (!ok) { imageImport.errors.push({ source: img.source, error: "URL validation failed" }); continue; }
        const { buffer } = await downloadImage(ctx, img.source);
        const sha256 = computeSha256(buffer);
        const records = await processAndStoreImageFiles(buffer, janCode, img.source, {
          alt: img.alt, sortOrder: img.sortOrder ?? i,
        });
        for (const rec of records) {
          await upsertFigureImageRecord(ctx.prisma, {
            figureId: savedFigure.id, janCode: rec.janCode, sha256: rec.sha256,
            size: rec.size, format: rec.format, width: rec.width, height: rec.height,
            fileSize: rec.fileSize, alt: rec.alt || null, sortOrder: rec.sortOrder,
            source: rec.source, isNsfw: rec.isNsfw || false,
          });
          imageImport.created += 1;
        }
      } catch (err: any) {
        imageImport.errors.push({ source: img.source, error: err?.message || "Image processing failed" });
      }
    }
  }

  if (hasImages && imagesRequired && imageImport.created === 0 && imageImport.errors.length > 0) {
    throw new ApplyDependencyError("IMAGE_PROCESSING", "All images failed to import");
  }

  lease.assertHeld();
  let revision: any = null;
  const rewrite = payload.rewrite || payload.rewriteDraft;
  if (rewrite?.contentMd) {
    const maxRev = await ctx.prisma.revision.aggregate({
      where: { figureId: savedFigure.id },
      _max: { versionNumber: true },
    });
    const nextVersion = (maxRev._max.versionNumber || 0) + 1;

    const revisionResult = await ctx.prisma.$transaction(async (tx: any) => {
      await tx.revision.updateMany({ where: { figureId: savedFigure.id }, data: { isActive: false } });
      const rev = await tx.revision.create({
        data: {
          figureId: savedFigure.id, contentMd: rewrite.contentMd,
          summaryMd: rewrite.summaryMd || null,
          keyPoints: Array.isArray(rewrite.keyPoints) ? rewrite.keyPoints : [],
          relatedKeywords: Array.isArray(rewrite.relatedKeywords) ? rewrite.relatedKeywords : [],
          versionNumber: nextVersion,
          editSummary: rewrite.editSummary || "Created from figure import review",
          editorId: ctx.actorUserId ? BigInt(ctx.actorUserId) : null,
          isActive: true,
          promptVersion: rewrite.promptVersion || item.automation?.workflow || null,
          qualityScore: typeof rewrite.qualityScore === "number" ? rewrite.qualityScore : null,
        },
      });
      await tx.figure.update({ where: { id: savedFigure.id }, data: { activeRevisionId: rev.id } });
      return rev;
    });
    revision = revisionResult;
  }

  return {
    applied: {
      action: existingFigure ? "merged" : "created",
      figure: { id: String(savedFigure.id), slug: savedFigure.slug },
      imageImport,
      revision: revision ? { id: String(revision.id), versionNumber: revision.versionNumber } : null,
    },
    partialSideEffects: { figureCreated: !existingFigure },
    failureStage: imageImport.errors.length > 0 ? "IMAGE_PROCESSING" : undefined,
  };
}

async function handleJanMatch(ctx: ApplyBusinessContext, item: any, payload: any, lease: LockLease): Promise<{ applied: any }> {
  const figure = await resolveFigure(ctx.prisma, item, payload);
  if (!figure) throw new ApplyValidationError("Figure not found");
  if (!payload.janCode) throw new ApplyValidationError("Missing JAN code");

  lease.assertHeld();
  const updated = await ctx.prisma.figure.update({
    where: { id: figure.id }, data: { janCode: String(payload.janCode) },
    select: { id: true, slug: true, janCode: true },
  });
  return { applied: updated };
}

async function handleRewrite(ctx: ApplyBusinessContext, item: any, payload: any, lease: LockLease): Promise<{ applied: any }> {
  const figure = await resolveFigure(ctx.prisma, item, payload);
  if (!figure) throw new ApplyValidationError("Figure not found");
  if (!payload.contentMd) throw new ApplyValidationError("Missing contentMd");

  const maxRev = await ctx.prisma.revision.aggregate({
    where: { figureId: figure.id },
    _max: { versionNumber: true },
  });
  const nextVersion = (maxRev._max.versionNumber || 0) + 1;

  lease.assertHeld();
  const revision = await ctx.prisma.$transaction(async (tx: any) => {
    await tx.revision.updateMany({ where: { figureId: figure.id }, data: { isActive: false } });
    const rev = await tx.revision.create({
      data: {
        figureId: figure.id, contentMd: String(payload.contentMd),
        summaryMd: payload.summaryMd || null,
        keyPoints: Array.isArray(payload.keyPoints) ? payload.keyPoints : [],
        relatedKeywords: Array.isArray(payload.relatedKeywords) ? payload.relatedKeywords : [],
        versionNumber: nextVersion,
        editSummary: payload.editSummary || "Applied from review queue",
        editorId: ctx.actorUserId ? BigInt(ctx.actorUserId) : null,
        isActive: true,
        promptVersion: payload.promptVersion || item.automation?.workflow || null,
        qualityScore: typeof payload.qualityScore === "number" ? payload.qualityScore : null,
      },
    });
    await tx.figure.update({ where: { id: figure.id }, data: { activeRevisionId: rev.id } });
    return rev;
  });

  return { applied: { id: String(revision.id), versionNumber: revision.versionNumber } };
}

async function handleImage(ctx: ApplyBusinessContext, item: any, payload: any, lease: LockLease): Promise<{ applied: any; failureStage?: string }> {
  const figure = await resolveFigure(ctx.prisma, item, payload);
  if (!figure) throw new ApplyValidationError("Figure not found");

  const images = Array.isArray(payload.images) ? payload.images : [];
  const processedImages = Array.isArray(payload.processedImages) ? payload.processedImages : [];
  if (images.length === 0 && processedImages.length === 0) throw new ApplyValidationError("No images to process");

  const imageImport = { created: 0, errors: [] as Array<{ source: string; error: string }> };
  const janCode = String(payload.janCode || figure.janCode || "no-jancode");
  const createdSha256s: string[] = [];

  for (const processed of processedImages) {
    lease.assertHeld();
    try {
      const stored = await storeProcessedReviewImage(ctx, figure.id, janCode, processed);
      if (!stored.updated) imageImport.created += 1;
      if (stored.sha256 && !createdSha256s.includes(stored.sha256)) createdSha256s.push(stored.sha256);
    } catch (err: any) {
      imageImport.errors.push({ source: processed?.source || "processed-image", error: err?.message || "Processed image import failed" });
    }
  }

  const processedSources = new Set(processedImages.map((img: any) => img?.source).filter(Boolean).map(String));

  for (let i = 0; i < images.length; i++) {
    lease.assertHeld();
    const img = images[i] || {};
    const source = img.source || img.url;
    if (source && processedSources.has(String(source))) continue;
    if (!source) { imageImport.errors.push({ source: "", error: "Missing image source" }); continue; }
    try {
      const { ok } = await validateImageUrl(source);
      if (!ok) throw new Error("URL validation failed");
      const { buffer } = await downloadImage(ctx, source);
      const sha256 = computeSha256(buffer);
      const records = await processAndStoreImageFiles(buffer, janCode, source, {
        alt: img.alt, sortOrder: img.sortOrder ?? i,
      });
      for (const rec of records) {
        await upsertFigureImageRecord(ctx.prisma, {
          figureId: figure.id, janCode: rec.janCode, sha256: rec.sha256,
          size: rec.size, format: rec.format, width: rec.width, height: rec.height,
          fileSize: rec.fileSize, alt: rec.alt || null, sortOrder: rec.sortOrder,
          source: rec.source, isNsfw: rec.isNsfw || false,
        });
        imageImport.created += 1;
      }
      for (const rec of records) {
        if (rec.sha256 && !createdSha256s.includes(rec.sha256)) createdSha256s.push(rec.sha256);
      }
    } catch (err: any) {
      imageImport.errors.push({ source, error: err?.message || "Image processing failed" });
    }
  }

  if (imageImport.created === 0 && imageImport.errors.length > 0) {
    throw new ApplyDependencyError("IMAGE_PROCESSING", "All images failed to import");
  }

  lease.assertHeld();
  const deleteWhere: any[] = [];
  const deleteImageIds = Array.isArray(payload.deleteImageIds) ? payload.deleteImageIds : [];
  const deleteSha256s = Array.isArray(payload.deleteSha256s) ? payload.deleteSha256s : [];
  const deleteSources = Array.isArray(payload.deleteSources) ? payload.deleteSources : [];
  if (deleteImageIds.length) deleteWhere.push({ id: { in: deleteImageIds.map((imageId: any) => BigInt(String(imageId))) } });
  if (deleteSha256s.length) deleteWhere.push({ sha256: { in: deleteSha256s.map(String) } });
  if (deleteSources.length) deleteWhere.push({ source: { in: deleteSources.map(String) } });

  let deleted = 0;
  if (deleteWhere.length) {
    const result = await ctx.prisma.figureImage.deleteMany({
      where: { figureId: figure.id, OR: deleteWhere, NOT: createdSha256s.length ? { sha256: { in: createdSha256s } } : undefined },
    });
    deleted = result.count;
  }

  return {
    applied: { action: "images_imported", figure: { id: String(figure.id), slug: figure.slug }, imageImport, deleted },
    failureStage: imageImport.errors.length > 0 ? "IMAGE_PROCESSING" : undefined,
  };
}

async function handleImageReview(ctx: ApplyBusinessContext, item: any, payload: any, lease: LockLease): Promise<{ applied: any; failureStage?: string }> {
  const action = payload.action || "approve_image";
  if (action !== "approve_image") throw new ApplyValidationError(`image_review /apply only supports approve_image, got: ${action}`);

  const figure = await resolveFigure(ctx.prisma, item, payload);
  if (!figure) throw new ApplyValidationError("Figure not found");

  const cand = item.candidateImage;
  if (!cand || !cand.source) throw new ApplyValidationError("No candidateImage to approve");

  const existing = await ctx.prisma.figureImage.findFirst({
    where: { figureId: figure.id, source: cand.source },
    select: { id: true, source: true, sortOrder: true },
  });

  if (existing) {
    lease.assertHeld();
    await ctx.prisma.figureImage.update({
      where: { id: existing.id },
      data: {
        data: { source_kind: "mfc_review_approved", safe_display: true, image_low_quality: false, reviewed_by_admin: true, review_item_id: item.id },
        sortOrder: 0,
      },
    });
    return { applied: { action: "already_approved", figure: { id: String(figure.id), slug: figure.slug }, imageId: String(existing.id), source: cand.source } };
  }

  const janCode = figure.janCode || "no-jancode";
  const { ok } = await validateImageUrl(cand.source);
  if (!ok) throw new ApplyDependencyError("IMAGE_SECURITY", "URL validation failed for candidate image");

  const { buffer } = await downloadImage(ctx, cand.source);
  const sha256 = computeSha256(buffer);

  lease.assertHeld();
  const imageRecords = await processAndStoreImageFiles(buffer, janCode, cand.source, {
    alt: undefined, sortOrder: 0, isNsfw: false,
  });

  let firstImageId: string | null = null;
  let processedCount = 0;
  for (const rec of imageRecords) {
    lease.assertHeld();
    const result = await upsertFigureImageRecord(ctx.prisma, {
      figureId: figure.id, janCode: rec.janCode, sha256: rec.sha256,
      size: rec.size, format: rec.format, width: rec.width, height: rec.height,
      fileSize: rec.fileSize, alt: rec.alt || null, sortOrder: rec.sortOrder,
      source: rec.source, isNsfw: rec.isNsfw || false,
      data: { source_kind: "mfc_review_approved", safe_display: true, image_low_quality: false, reviewed_by_admin: true, review_item_id: item.id },
    });
    if (result.created && firstImageId === null) firstImageId = String(result.image.id);
    processedCount++;
  }

  return {
    applied: { action: "image_approved", figure: { id: String(figure.id), slug: figure.slug }, imageId: firstImageId, source: cand.source, processedCount },
  };
}

export async function executeApplyBusiness(
  ctx: ApplyBusinessContext,
  input: ApplyBusinessInput,
  lease: LockLease,
): Promise<ApplyBusinessResult> {
  lease.assertHeld();
  const raw = await ctx.redis.get(`review:item:${input.reviewItemId}`);
  if (!raw) throw new ApplyValidationError(`Review item ${input.reviewItemId} not found`);

  const item = JSON.parse(raw);
  const mergedPayload = { ...(item.payload || {}), ...(input.body || {}) };

  let payload: Record<string, unknown>;
  try {
    const schemaMap: Record<string, z.ZodSchema> = {
      figure_import: figureImportApplySchema,
      jan_match: janMatchApplySchema,
      rewrite: rewriteApplySchema,
      image: imageApplySchema,
      image_review: imageReviewApplySchema,
    };
    const schema = schemaMap[item.type];
    if (schema) {
      payload = schema.parse(mergedPayload) as Record<string, unknown>;
    } else {
      payload = mergedPayload;
    }
  } catch (err: any) {
    if (err instanceof z.ZodError) {
      throw new ApplyValidationError("Schema validation failed: " + err.errors.map((e: any) => e.path.join(".") + " " + e.message).join("; "));
    }
    throw err;
  }

  let applied: any = null;
  let partialSideEffects: any = undefined;
  let failureStage: string | undefined = undefined;

  if (item.type === "figure_import") {
    const result = await handleFigureImport(ctx, item, payload, lease);
    applied = result.applied;
    partialSideEffects = result.partialSideEffects;
    failureStage = result.failureStage;
  } else if (item.type === "jan_match") {
    const result = await handleJanMatch(ctx, item, payload, lease);
    applied = result.applied;
  } else if (item.type === "rewrite") {
    const result = await handleRewrite(ctx, item, payload, lease);
    applied = result.applied;
  } else if (item.type === "image") {
    const result = await handleImage(ctx, item, payload, lease);
    applied = result.applied;
    failureStage = result.failureStage;
  } else if (item.type === "image_review") {
    const result = await handleImageReview(ctx, item, payload, lease);
    applied = result.applied;
  } else {
    throw new ApplyValidationError(`Unsupported review type: ${item.type}`);
  }

  lease.assertHeld();

  const now = new Date().toISOString();
  const problems = await evaluateReviewResult(ctx, item);
  const hasPartialFailure = failureStage !== undefined;
  const hasAllFailure = failureStage !== undefined && applied?.imageImport?.created === 0;

  const newStatus = hasAllFailure ? "needs_changes" : problems.length === 0 && !hasPartialFailure ? "resolved" : "needs_changes";
  const noteParts: string[] = [];
  if (hasPartialFailure) noteParts.push("partial failure at " + failureStage);
  if (problems.length > 0) noteParts.push("problems: " + problems.join("; "));
  const noteText = noteParts.length > 0
    ? `Applied by ${ctx.actorUserId} at ${now}, ${noteParts.join("; ")}`
    : `Applied by ${ctx.actorUserId} at ${now}`;

  const updatedItem = {
    ...item,
    payload: { ...(item.payload || {}), reviewProblems: problems, lastCheckedAt: now, appliedResult: applied },
    status: newStatus,
    notes: item.notes ? `${item.notes}\n${noteText}` : noteText,
    updatedAt: now,
    reviewer: ctx.actorUserId || null,
    decisionAt: newStatus === "resolved" ? now : item.decisionAt,
  };

  lease.assertHeld();
  await ctx.redis.set(`review:item:${input.reviewItemId}`, JSON.stringify(updatedItem));

  lease.assertHeld();
  await scanKeys(ctx.redis, "figures:*");

  return {
    success: newStatus === "resolved",
    applied,
    reviewStatus: newStatus,
    problems,
    figure: applied?.figure || undefined,
    partialSideEffects,
    failureStage,
  };
}

async function evaluateReviewResult(ctx: ApplyBusinessContext, item: any): Promise<string[]> {
  const payload = item.payload || {};
  const figure = await resolveFigure(ctx.prisma, item, payload);
  const problems: string[] = [];

  if (["image", "image_review", "rewrite", "jan_match", "detail_review"].includes(item.type) && !figure) {
    problems.push("FIGURE_NOT_FOUND");
    return problems;
  }

  if (item.type === "image" && figure) {
    const rows = await ctx.prisma.figureImage.findMany({
      where: { figureId: figure.id },
      select: { id: true, source: true, size: true, width: true, height: true, sha256: true },
      orderBy: [{ sortOrder: "asc" }, { id: "asc" }],
    });
    if (rows.length === 0) problems.push("仍然没有图片");
  }

  if (item.type === "rewrite" && figure) {
    const activeRevision = await ctx.prisma.revision.findFirst({
      where: { figureId: figure.id, isActive: true },
      select: { id: true, contentMd: true },
    });
    if (!activeRevision || !activeRevision.contentMd || activeRevision.contentMd.trim().length < 80) problems.push("洗稿正文仍为空或过短");
  }

  if (item.type === "figure_import") {
    const slug = payload.figure?.slug || payload.slug || item.figureSlug;
    if (slug) {
      const existing = await ctx.prisma.figure.findFirst({ where: { slug: String(slug), isDeleted: false }, select: { id: true } });
      if (!existing) problems.push("候选手办仍未入库");
    }
  }

  return problems;
}
