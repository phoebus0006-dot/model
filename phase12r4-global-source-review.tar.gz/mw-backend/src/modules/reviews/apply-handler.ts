// Legacy compatibility stub — real apply logic moved to apply-business.ts and apply-route.ts
// This file intentionally left minimal. All production paths reference apply-route.ts directly.

export async function adminApplyRoute(app: any) {
  throw new Error("DEPRECATED: adminApplyRoute in apply-handler.ts is no longer supported. Use apply-route.ts instead.");
}
