﻿import { z } from "zod";
import { REVIEW_STATUSES, REVIEW_TYPES, REVIEW_RISK_TYPES, REVIEW_ACTIONS } from "./types.js";

export const reviewStatusSchema = z.enum(REVIEW_STATUSES);
export const queryReviewStatusSchema = z.union([reviewStatusSchema, z.literal("all")]);
export const reviewTypeSchema = z.enum(REVIEW_TYPES);
export const reviewRiskTypeSchema = z.enum(REVIEW_RISK_TYPES);
export const reviewActionSchema = z.enum(REVIEW_ACTIONS);

const automationSchema = z.object({
  provider: z.enum(["n8n", "hermes", "manual", "other"]).default("manual"),
  workflow: z.string().optional(),
  runId: z.string().optional(),
}).optional();

const candidateImageSchema = z.object({
  source: z.string(),
  imageId: z.union([z.number(), z.string()]).optional(),
  width: z.number().int().optional(),
  height: z.number().int().optional(),
  fileSize: z.number().int().optional(),
  aspectRatio: z.number().optional(),
  url: z.string().optional(),
  cachedUrl: z.string().optional(),
}).passthrough().optional();

const currentPublicImageSchema = z.object({
  imageId: z.union([z.number(), z.string()]).optional(),
  source: z.string().optional(),
  width: z.number().int().optional(),
  height: z.number().int().optional(),
}).optional();

const detailSnapshotSchema = z.object({
  description: z.string().optional(),
  specCount: z.number().int().optional(),
  specs: z.any().optional(),
  categories: z.array(z.any()).optional(),
}).optional();

export const reviewItemSchema = z.object({
  type: reviewTypeSchema.default("general"),
  title: z.string().min(1),
  source: z.string().optional(),
  sourceId: z.string().optional(),
  status: reviewStatusSchema.default("pending"),
  priority: z.coerce.number().int().min(0).max(3).default(1),
  confidence: z.coerce.number().min(0).max(1).optional(),
  figureId: z.union([z.number().int(), z.string()]).optional(),
  figureSlug: z.string().optional(),
  riskType: reviewRiskTypeSchema.optional(),
  riskReason: z.string().max(1000).optional(),
  candidateImage: candidateImageSchema,
  currentPublicImage: currentPublicImageSchema,
  detailSnapshot: detailSnapshotSchema,
  suggestedAction: reviewActionSchema.optional(),
  payload: z.any().optional(),
  notes: z.string().optional(),
  automation: automationSchema,
  evidenceFingerprint: z.string().min(16).max(128).optional(),
  decisionReason: z.string().max(1000).nullable().optional(),
  reviewer: z.string().max(200).nullable().optional(),
  decisionAt: z.string().datetime().nullable().optional(),
});

export const candidateImageUpdateSchema = z.object({
  source: z.string(),
  imageId: z.union([z.number(), z.string()]).optional(),
  width: z.number().int().optional(),
  height: z.number().int().optional(),
  fileSize: z.number().int().optional(),
  aspectRatio: z.number().optional(),
  url: z.string().optional(),
  cachedUrl: z.string().optional(),
}).passthrough().optional();

export const reviewUpdateSchema = z.object({
  status: reviewStatusSchema.optional(),
  priority: z.coerce.number().int().min(0).max(3).optional(),
  confidence: z.coerce.number().min(0).max(1).optional(),
  payload: z.any().optional(),
  notes: z.string().max(2000).optional(),
  automation: automationSchema,
  candidateImage: candidateImageUpdateSchema,
  suggestedAction: reviewActionSchema.optional(),
  currentPublicImage: currentPublicImageSchema,
  evidenceFingerprint: z.string().min(16).max(128).optional(),
  decisionReason: z.string().max(1000).nullable().optional(),
  reviewer: z.string().max(200).nullable().optional(),
  decisionAt: z.string().datetime().nullable().optional(),
});

// Safe editable fields — explicitly excludes status, reviewer, decisionReason, decisionAt
export const reviewEditableFieldsSchema = z.object({
  priority: z.coerce.number().int().min(0).max(3).optional(),
  confidence: z.coerce.number().min(0).max(1).optional(),
  payload: z.any().optional(),
  notes: z.string().max(2000).optional(),
  automation: automationSchema,
  candidateImage: candidateImageUpdateSchema,
  suggestedAction: reviewActionSchema.optional(),
  currentPublicImage: currentPublicImageSchema,
  evidenceFingerprint: z.string().min(16).max(128).optional(),
}).strict();

export const reviewQuerySchema = z.object({
  status: queryReviewStatusSchema.optional(),
  type: reviewTypeSchema.optional(),
  riskType: reviewRiskTypeSchema.optional(),
  suggestedAction: reviewActionSchema.optional(),
  limit: z.coerce.number().int().min(1).max(200).default(50),
  offset: z.coerce.number().int().min(0).default(0),
});

export const reviewDecisionQuerySchema = z.object({
  figureId: z.string().trim().min(1).optional(),
  figureSlug: z.string().trim().min(1).optional(),
  riskType: reviewRiskTypeSchema.optional(),
  action: reviewActionSchema.optional(),
  limit: z.coerce.number().int().min(1).max(200).default(50),
  offset: z.coerce.number().int().min(0).default(0),
});

export const bulkCleanupSchema = z.object({
  dryRun: z.boolean().default(false),
  markStale: z.boolean().default(true),
  olderThanDays: z.coerce.number().int().min(1).default(1),
});

const figureImportImageSchema = z.object({
  source: z.string().url(),
  alt: z.string().optional(),
  sortOrder: z.number().int().optional(),
  janCode: z.string().optional(),
}).strict();

const styleSchema = z.object({
  id: z.number().int(),
  role: z.string().optional(),
  isPrimary: z.boolean().optional(),
}).strict();

const characterShortSchema = z.object({
  id: z.number().int(),
  isFeatured: z.boolean().optional(),
}).strict();

const localizedSchema = z.object({
  language: z.string().min(1),
  title: z.string().optional(),
  origin: z.string().optional(),
  character: z.string().optional(),
  description: z.string().optional(),
}).strict();

const releaseSchema = z.object({
  edition: z.string().optional(),
  releaseDate: z.string().optional(),
  priceJpy: z.number().int().optional(),
  isRerelease: z.boolean().optional(),
}).strict();

const figureImportFigureSchema = z.object({
  slug: z.string().min(1),
  name: z.string().min(1),
  janCode: z.string().optional(),
  description: z.string().optional(),
  scale: z.string().optional(),
  material: z.string().optional(),
  priceJpy: z.number().int().optional(),
  heightMm: z.number().int().optional(),
  weightG: z.number().int().optional(),
  productLine: z.string().optional(),
  ageRating: z.string().optional(),
  isNsfw: z.boolean().optional(),
  manufacturerId: z.number().int().optional(),
  seriesId: z.number().int().optional(),
  originalNameJa: z.string().optional(),
  originalNameZh: z.string().optional(),
  categoryIds: z.array(z.number().int()).optional(),
  sculptorIds: z.array(styleSchema).optional(),
  characterIds: z.array(characterShortSchema).optional(),
  localized: z.array(localizedSchema).optional(),
  releases: z.array(releaseSchema).optional(),
  images: z.array(figureImportImageSchema).optional(),
}).strict();

const processedImageSchema = z.object({
  source: z.string().optional(),
  size: z.enum(["raw", "detail", "thumb"]),
  sha256: z.string().regex(/^[a-f0-9]{64}$/i),
  contentBase64: z.string().min(1),
  format: z.string().optional(),
  width: z.number().int().optional(),
  height: z.number().int().optional(),
  fileSize: z.number().int().optional(),
  alt: z.string().optional(),
  sortOrder: z.number().int().optional(),
  isNsfw: z.boolean().optional(),
}).strict().refine((d) => {
  const buf = Buffer.from(d.contentBase64, "base64");
  return buf.length > 0;
}, "contentBase64 must be valid base64");

const imageSourceSchema = z.object({
  source: z.string().url(),
  url: z.string().optional(),
  alt: z.string().optional(),
  sortOrder: z.number().int().optional(),
  janCode: z.string().optional(),
}).strict();

export const figureImportApplySchema = z.object({
  figure: figureImportFigureSchema,
  importImages: z.boolean().optional(),
  rewrite: z.any().optional(),
  rewriteDraft: z.any().optional(),
}).strict();

export const janMatchApplySchema = z.object({
  janCode: z.string().min(1),
}).strict();

export const rewriteApplySchema = z.object({
  contentMd: z.string().min(1),
  summaryMd: z.string().optional(),
  keyPoints: z.array(z.string()).optional(),
  relatedKeywords: z.array(z.string()).optional(),
  editSummary: z.string().optional(),
  promptVersion: z.string().optional(),
  qualityScore: z.number().min(0).max(1).optional(),
}).strict();

export const imageApplySchema = z.object({
  images: z.array(imageSourceSchema).optional(),
  processedImages: z.array(processedImageSchema).optional(),
  janCode: z.string().optional(),
  deleteImageIds: z.array(z.union([z.string(), z.number()])).optional(),
  deleteSha256s: z.array(z.string()).optional(),
  deleteSources: z.array(z.string()).optional(),
}).strict();

export const imageReviewApplySchema = z.object({
  action: z.enum(["approve_image"]).optional(),
}).strict();
