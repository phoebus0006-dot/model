import type { FastifyInstance, FastifyRequest, FastifyReply } from "fastify";
import { ReviewApplyService } from "./apply-service.js";
import { ReviewNotFound, InvalidReviewState, ApplyLockConflict, ApplyDependencyError, ApplyValidationError } from "./apply-errors.js";

interface ApplyParams { id: string }

export async function adminApplyRoute(app: FastifyInstance) {
  const applyService = new ReviewApplyService(app.redis, app.prisma);

  app.post("/review/items/:id/apply", async (req: FastifyRequest<{ Params: ApplyParams }>, reply: FastifyReply) => {
    try {
      const { id } = req.params;
      const actorUserId = String((req as any).user?.userId || "");
      const requestId = (req as any).id || "";
      const body = (req.body || {}) as Record<string, unknown>;
      const action = String(body.action || "");

      const result = await applyService.apply({
        reviewItemId: id,
        actorUserId,
        requestId,
        action: action || undefined,
        body,
      });

      if (!result.success) {
        return reply.status(422).send({
          success: false,
          error: { code: "APPLY_PARTIAL_FAILURE", message: "Apply completed with failures", stage: result.failureStage, reviewStatus: result.reviewStatus },
          data: { applied: result.applied, reviewStatus: result.reviewStatus, problems: result.problems, failureStage: result.failureStage, partialSideEffects: result.partialSideEffects },
        });
      }

      return reply.send({ success: true, data: result });
    } catch (e: any) {
      if (e instanceof ReviewNotFound) return reply.status(404).send({ success: false, error: { code: e.code, message: e.message } });
      if (e instanceof InvalidReviewState) return reply.status(409).send({ success: false, error: { code: e.code, message: e.message } });
      if (e instanceof ApplyLockConflict) return reply.status(409).send({ success: false, error: { code: e.code, message: e.message } });
      if (e instanceof ApplyDependencyError) return reply.status(422).send({ success: false, error: { code: e.code, message: e.message, stage: e.stage } });
      if (e instanceof ApplyValidationError) return reply.status(422).send({ success: false, error: { code: e.code, message: e.message } });
      return reply.status(500).send({ success: false, error: { code: "APPLY_INTERNAL_ERROR", message: "Internal error during apply" } });
    }
  });
}
