import type { PrismaClient } from "@prisma/client";
import { validateImageUrl } from "../images/image-security.js";
import { processAndStoreImageFiles, computeSha256 } from "../images/image-storage.js";
import { upsertFigureImageRecord } from "../images/image-repository.js";

export interface ApplyDependencies {
  createOrUpdateFigure(data: any): Promise<any>;
  updateRelations(figureId: bigint, relations: any): Promise<void>;
  storeImages(figureId: bigint, images: any[]): Promise<{ created: number; errors: any[] }>;
  createRevision(figureId: bigint, data: any): Promise<any>;
  setCurrentRevision(figureId: bigint, revisionId: bigint): Promise<void>;
  invalidateCache(pattern: string): Promise<void>;
}

export function createApplyDependencies(prisma: PrismaClient): ApplyDependencies {
  return {
    async createOrUpdateFigure(data: any) {
      const { id, ...rest } = data;
      if (id) {
        return prisma.figure.update({ where: { id: BigInt(String(id)) }, data: rest });
      }
      return prisma.figure.create({ data: rest });
    },

    async updateRelations(figureId: bigint, relations: any) {
      const ops: Promise<any>[] = [];
      if (relations.categories) {
        ops.push(prisma.figureCategory.deleteMany({ where: { figureId } }));
        ops.push(...(relations.categories || []).map((c: any) =>
          prisma.figureCategory.create({ data: { figureId, categoryId: c.id || c } })
        ));
      }
      if (relations.characters) {
        ops.push(prisma.figureCharacter.deleteMany({ where: { figureId } }));
        ops.push(...(relations.characters || []).map((ch: any) =>
          prisma.figureCharacter.create({ data: { figureId, characterId: ch.id || ch, isFeatured: ch.isFeatured ?? false } })
        ));
      }
      await Promise.all(ops);
    },

    async storeImages(figureId: bigint, images: any[]) {
      const created = 0;
      const errors: any[] = [];
      for (const img of images) {
        try {
          const { ok } = await validateImageUrl(img.source);
          if (!ok) { errors.push({ source: img.source, error: "URL validation failed" }); continue; }
          const janCode = img.janCode || "no-jancode";
          const buffer = Buffer.alloc(0); // would be from download
          const sha256 = computeSha256(buffer);
          const records = await processAndStoreImageFiles(buffer, janCode, img.source, { alt: img.alt, sortOrder: img.sortOrder });
          for (const rec of records) {
            await upsertFigureImageRecord(prisma, {
              figureId, janCode: rec.janCode, sha256: rec.sha256,
              size: rec.size, format: rec.format, width: rec.width, height: rec.height,
              fileSize: rec.fileSize, alt: rec.alt || null, sortOrder: rec.sortOrder,
              source: rec.source, isNsfw: rec.isNsfw || false,
            });
          }
        } catch (err: any) {
          errors.push({ source: img.source, error: err.message });
        }
      }
      return { created, errors };
    },

    async createRevision(figureId: bigint, data: any) {
      const maxRev = await prisma.revision.aggregate({
        where: { figureId },
        _max: { versionNumber: true },
      });
      const nextVersion = (maxRev._max.versionNumber || 0) + 1;
      await prisma.revision.updateMany({ where: { figureId }, data: { isActive: false } });
      return prisma.revision.create({
        data: {
          figureId,
          contentMd: String(data.contentMd || ""),
          summaryMd: data.summaryMd || null,
          keyPoints: Array.isArray(data.keyPoints) ? data.keyPoints : [],
          relatedKeywords: Array.isArray(data.relatedKeywords) ? data.relatedKeywords : [],
          versionNumber: nextVersion,
          editSummary: data.editSummary || "Applied from review queue",
          editorId: data.editorId ? BigInt(String(data.editorId)) : null,
          isActive: true,
          promptVersion: data.promptVersion || null,
          qualityScore: typeof data.qualityScore === "number" ? data.qualityScore : null,
        },
      });
    },

    async setCurrentRevision(figureId: bigint, revisionId: bigint) {
      await prisma.figure.update({ where: { id: figureId }, data: { activeRevisionId: revisionId } });
    },

    async invalidateCache(pattern: string) {
      const { scanKeys } = await import("../../shared/cache/scan-keys.js");
      const { default: Redis } = await import("ioredis");
      const redis = new Redis(process.env.REDIS_URL || "redis://localhost:6379");
      await scanKeys(redis, pattern);
      await redis.quit();
    },
  };
}
