import type { PrismaClient } from "@prisma/client";
import https from "https";
import http from "http";
import fs from "fs";
import path from "path";
import crypto from "crypto";
import { validateImageUrl } from "./image-security.js";
import { processAndStoreImageFiles, computeSha256, validateJanCode, DOWNLOAD_TIMEOUT, MAX_RESPONSE_SIZE, MAX_REDIRECTS, type ImageRecordData } from "./image-storage.js";
import { upsertFigureImageRecord, type UpsertFigureImageInput } from "./image-repository.js";

export class ImageDownloadError extends Error {
  constructor(message: string, public source?: string) { super(message); this.name = "ImageDownloadError"; }
}

export class ImageValidationError extends Error {
  constructor(message: string) { super(message); this.name = "ImageValidationError"; }
}

interface DownloadResult { buffer: Buffer; contentType: string; }

async function downloadImage(imageUrl: string, redirectDepth = 0): Promise<DownloadResult> {
  if (redirectDepth > MAX_REDIRECTS) throw new ImageDownloadError("Too many redirects", imageUrl);
  const { ok, resolvedAddress } = await validateImageUrl(imageUrl);
  if (!ok) throw new ImageDownloadError("URL validation failed", imageUrl);

  const urlObj = new URL(imageUrl);
  const isHttps = imageUrl.startsWith("https");
  const client = isHttps ? https : http;

  return new Promise((resolve, reject) => {
    const options: any = {
      hostname: resolvedAddress,
      port: urlObj.port || (isHttps ? 443 : 80),
      path: urlObj.pathname + urlObj.search,
      method: "GET",
      timeout: DOWNLOAD_TIMEOUT,
      headers: { "User-Agent": "ModelWiki/1.0", Host: urlObj.hostname },
      rejectUnauthorized: true,
      servername: urlObj.hostname,
    };
    const req = client.get(options, (res: any) => {
      if ((res.statusCode === 301 || res.statusCode === 302) && res.headers.location) {
        const nextUrl = new URL(res.headers.location, imageUrl).href;
        return downloadImage(nextUrl, redirectDepth + 1).then(resolve).catch(reject);
      }
      if (res.statusCode !== 200) return reject(new ImageDownloadError(`HTTP ${res.statusCode}`, imageUrl));
      const ct = res.headers["content-type"] || "";
      if (ct && !ct.startsWith("image/")) return reject(new ImageDownloadError("Not an image", imageUrl));
      const chunks: Buffer[] = [];
      let totalSize = 0;
      res.on("data", (chunk: Buffer) => {
        totalSize += chunk.length;
        if (totalSize > MAX_RESPONSE_SIZE) { req.destroy(); reject(new ImageDownloadError("Response too large", imageUrl)); }
        chunks.push(chunk);
      });
      res.on("end", () => resolve({ buffer: Buffer.concat(chunks), contentType: ct }));
    });
    req.on("error", (e: Error) => reject(new ImageDownloadError(e.message, imageUrl)));
    req.on("timeout", () => { req.destroy(); reject(new ImageDownloadError("Download timeout", imageUrl)); });
  });
}

export class ImageService {
  constructor(private prisma: PrismaClient) {}

  async processAndStoreFromUrl(
    imageUrl: string, janCode: string,
    options?: { alt?: string; sortOrder?: number; isNsfw?: boolean; figureId?: bigint }
  ): Promise<ImageRecordData[]> {
    if (!validateJanCode(janCode)) throw new ImageValidationError("Invalid janCode: " + janCode);

    const { buffer } = await downloadImage(imageUrl);
    const sha256 = computeSha256(buffer);
    const records = await processAndStoreImageFiles(buffer, janCode, imageUrl, {
      alt: options?.alt, sortOrder: options?.sortOrder ?? 0, isNsfw: options?.isNsfw ?? false,
    });

    for (const rec of records) {
      if (options?.figureId) {
        await upsertFigureImageRecord(this.prisma, {
          figureId: options.figureId, janCode: rec.janCode, sha256: rec.sha256,
          size: rec.size, format: rec.format, width: rec.width, height: rec.height,
          fileSize: rec.fileSize, alt: rec.alt || null, sortOrder: rec.sortOrder,
          source: rec.source, isNsfw: rec.isNsfw || false,
        });
      }
    }
    return records;
  }

  async storeProcessedImage(
    figureId: bigint, janCode: string, data: { size: string; sha256: string; contentBase64: string; source?: string; alt?: string; sortOrder?: number; isNsfw?: boolean }
  ): Promise<{ image: any; sha256: string; updated: boolean }> {
    if (!validateJanCode(janCode)) throw new ImageValidationError("Invalid janCode: " + janCode);
    if (!/^[a-f0-9]{64}$/i.test(data.sha256)) throw new ImageValidationError("Invalid sha256 format");

    const buffer = Buffer.from(data.contentBase64, "base64");
    if (!buffer.length) throw new ImageValidationError("Empty content");

    const actualSha256 = computeSha256(buffer);
    if (actualSha256 !== data.sha256) throw new ImageValidationError("SHA-256 mismatch");

    const metadata = await import("sharp").then(m => m.default(buffer).metadata());
    if (!metadata.format || !metadata.width || !metadata.height) throw new ImageValidationError("Not a valid image");

    const webpBuffer = await import("sharp").then(m => m.default(buffer).webp({ quality: 85 }).toBuffer());

    const filePath = this.getResolvedPath(janCode, actualSha256, data.size);
    const tmpPath = filePath + ".tmp." + crypto.randomBytes(8).toString("hex");
    const dir = path.dirname(filePath);
    fs.mkdirSync(dir, { recursive: true });
    try {
      fs.writeFileSync(tmpPath, webpBuffer);
      fs.renameSync(tmpPath, filePath);
    } catch (e) {
      try { fs.unlinkSync(tmpPath); } catch {}
      throw e;
    }

    const { image, created } = await upsertFigureImageRecord(this.prisma, {
      figureId, janCode, sha256: actualSha256, size: data.size, format: "webp",
      width: metadata.width, height: metadata.height, fileSize: webpBuffer.length,
      alt: data.alt || null, sortOrder: data.sortOrder ?? 0, source: data.source || null,
      isNsfw: data.isNsfw || false,
    });
    return { image, sha256: actualSha256, updated: !created };
  }

  private ASSETS_PATH = process.env.ASSETS_PATH || "/app/assets";

  private getResolvedPath(janCode: string, sha256: string, size: string): string {
    if (!validateJanCode(janCode)) throw new ImageValidationError("Invalid janCode: " + janCode);
    const resolved = path.resolve(this.ASSETS_PATH, "figures", janCode, `${sha256}_${size}.webp`);
    const expectedRoot = path.resolve(this.ASSETS_PATH, "figures") + path.sep;
    if (!resolved.startsWith(expectedRoot)) throw new ImageValidationError("Path traversal detected");
    return resolved;
  }
}

export { validateImageUrl };
